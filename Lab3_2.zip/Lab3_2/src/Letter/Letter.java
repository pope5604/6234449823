/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Letter;

public class Letter {

    private String Sender;
    private String Receiver;
    private String Message;
    public Letter(String from, String to){
        Sender = from;
        Receiver = to;
    }
    public void addLine(String line){
        Message = line;
    }
    public String getText(){
        return "Dear "+Receiver+":"+"\n\n"+Message+"\n\n"+"Sincerely,"+"\n\n"+Sender;
    }
}
