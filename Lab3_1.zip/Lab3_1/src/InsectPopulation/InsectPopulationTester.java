/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InsectPopulation;

public class InsectPopulationTester {
    public static void main(String[] args) {
        InsectPopulation Insectt;
        Insectt = new InsectPopulation(10);
        Insectt.breed();
        Insectt.spray();
    System.out.printf("Number of insect: ",Insectt.getNumInsect());Insectt.breed();Insectt.spray();
    System.out.printf("Number of insect: %.1f\n",Insectt.getNumInsect());Insectt.breed();Insectt.spray();
    System.out.printf("Number of insect: %.2f\n",Insectt.getNumInsect());
    }
}
