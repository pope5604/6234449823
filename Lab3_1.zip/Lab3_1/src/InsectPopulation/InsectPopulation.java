/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InsectPopulation;


public class InsectPopulation {

    private static double population;
    public InsectPopulation(int amount){
        population = amount;
    }
    public void breed(){
        population = 2*population;
    }
    public void spray(){
        population = population*0.9;
    }
    public double getNumInsect(){
        return population;
    }
}
