/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CashRegister;

public class CashRegister {
    private double tax;
    private double afterbuaktax;
    private double cost;
    private double total;
    public CashRegister(int vat){
        double kumnuantax = vat;
        tax = kumnuantax/100;
    }
    public void recordTaxablePurchase(double raka){
        total = tax*raka;
        raka = raka+(tax*raka);
        afterbuaktax += raka;
    }
    public void recordPurchase(double raka2){
        cost += raka2;
    }
    public double giveChange(double moneyafterbuy){
        double change = moneyafterbuy - (afterbuaktax + cost);
        return change;
    }
    public double getTotalTax(){
        return total;
    }
}    
