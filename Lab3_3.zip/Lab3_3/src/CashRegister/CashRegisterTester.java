/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package CashRegister;

public class CashRegisterTester {
    public static void main(String[] args){
        CashRegister vat = new CashRegister(7);
        vat.recordTaxablePurchase(20);
        vat.recordPurchase(10);
        vat.recordPurchase(50);
        System.out.printf("Your change is %.1f\n",vat.giveChange(100));
    }
}
